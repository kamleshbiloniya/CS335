
To run, use following command in 160317_CS335 directory

python src/lexer.py --cfg=tests/cfg1/1.txt tests/input1/input1.go --output=tests/output1/output.html

To open output file in browser, use following command

google-chrome tests/output1/output.html

OR

firefox tests/output1/output.html