package main
import "fmt"

func main() {
	for i := 0; i < 5; i++ {
		fmt.Println(i)
	}
	// commented code 
	k := 1
    for k <= 3 {
        fmt.Println(k)
        k = k + 1
    }
}