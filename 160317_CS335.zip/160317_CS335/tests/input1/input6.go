////////////taken from https://github.com/prannayk/CS335/blob/master/asgn1/test/6.go /////
package main;

import "fmt";

// Comments...


/* Error in function defination */
func < A:Doable $ Eatable   $    Shakeable,B: ChaitiLalal$ Chaiti , C> foldr(func f(a A, b B) B, id B, []A lst) B {
    if len(lst) == 0 {
        return id;
    }
    return f(head(A), foldr(f, id, tail(A)));
}  // end of function


gen TillTen() int {
    for i := 0; i != 10; i++ {
        yield i
    }
    return 0  // say hello to this world!
}